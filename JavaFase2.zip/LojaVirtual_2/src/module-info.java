/**
 * 
 */
/**
 * @author Hagna
 *
 */
module LojaVirtual {
}